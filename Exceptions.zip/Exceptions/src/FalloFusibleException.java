public class FalloFusibleException extends FalloMonitorException {
    public FalloFusibleException(){
        super("Fallo en el fusible");
    }
    public FalloFusibleException(String mensaje){
        super(mensaje);
}
}
